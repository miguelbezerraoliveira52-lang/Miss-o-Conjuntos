# Missão Conjuntos

Jogo educacional em **Godot 4.4.1 / GDScript**, em português, para alunos do ensino médio. Projeto baseado nas exigências do Projeto Aplicado AV2/AV3 fornecido pelo usuário.

## Jogar e editar

- **Windows 10/11, 64 bits:** extraia o pacote Windows e abra `MissaoConjuntos.exe`. O jogo contém os recursos embutidos; não exige Godot instalado. Executável sem assinatura digital. Exportado nesta entrega, mas não executado em um sistema Windows neste ambiente.
- **Projeto editável:** instale Godot 4.4.1 Standard (não precisa de .NET). Extraia o projeto, clique em Importar, selecione `project.godot` e execute com **F6 na cena principal ou F5**. Aguarde a importação inicial dos sons. Não funciona no Godot 3.
- **Web:** o pacote Web contém uma exportação pronta. Sirva seus arquivos por HTTP/HTTPS; abrir `index.html` por duplo clique não é suficiente. Para teste local, com Python instalado: `python -m http.server 8000` na pasta Web e acesse `http://localhost:8000`. Requer navegador com WebGL 2. O pacote não foi publicado automaticamente e ainda não possui URL pública.

## Enredo e objetivo

Uma tempestade danificou os arquivos da nave Atlas. A exploradora Lia precisa restaurar cinco setores para reconstruir o mapa e reativar o portal de retorno. Cada setor recuperado representa uma ferramenta matemática aprendida. Todos os setores ficam acessíveis para permitir revisão livre; concluir os cinco revela o encerramento da história.

## Conteúdo e mecânica

| Setor | Conteúdo | Interação |
|---|---|---|
| O arquivo perdido | Definição, pertinência, repetição, vazio | Selecionar elementos de uma coleção |
| Pontes de união | A ∪ B | Reunir elementos dos dois conjuntos |
| O núcleo comum | A ∩ B | Identificar elementos compartilhados |
| Além da fronteira | Complemento em U | Selecionar elementos de U fora de A |
| Coleções dentro de coleções | C ⊆ A | Selecionar conjuntos inteiros que são subconjuntos |

São **30 desafios**, seis por tema. Cada missão sorteia três sem repetição na mesma partida. Completar os cinco setores produz **15 interações**. Há ainda uma avaliação com **15 questões no banco**, que sorteia dez por partida, duas de cada tema. O quiz exibe uma questão por vez, com uma resposta correta. A posição das alternativas é fixa; as questões são sorteadas.

União e interseção possuem diagramas de Venn com os elementos distribuídos por região. O jogador responde usando os botões abaixo do diagrama. Nas demais missões, lê o universo e os conjuntos indicados. Nenhuma resposta depende apenas de distinguir cores.

## Controles e regras

- Mouse: clique para marcar/desmarcar. Em Subconjuntos, cada opção representa um conjunto completo.
- Teclado: Tab e Shift+Tab navegam; Espaço ou Enter acionam botões.
- Para indicar conjunto vazio nas missões, não marque nenhum item e confirme.
- No quiz, selecione exatamente uma alternativa. Não é permitido confirmar em branco.
- As missões permitem corrigir erros. Pontos por desafio: 100 no primeiro acerto, 75 após um erro, 50 após dois ou mais erros.
- Uma missão concluída concede uma estrela; 225 pontos ou mais concedem duas; 300 concedem três.
- O quiz registra um ponto por resposta correta, sem segunda tentativa na mesma questão.
- Consultar dicas não reduz pontos. Não há limite de tempo nem vidas.
- Som opcional, com sinais distintos para acerto e erro; texto e símbolos também informam o resultado.
- O botão Início abandona a partida atual. Apenas resultados concluídos ficam salvos.
- Melhores estrelas, recorde do quiz e preferência de som são salvos localmente em `user://progress.cfg`.
- Apagar progresso exige confirmação. Não são coletados nomes, emails ou dados pessoais.

## Organização do código

- `main.tscn`: cena de entrada. A interface é criada por código.
- `scripts/main.gd`: telas, sorteio, seleção, feedback, pontuação e persistência.
- `scripts/venn.gd`: desenho e distribuição dos elementos no diagrama.
- `assets/data.json`: textos, desafios, alternativas e gabaritos.
- `assets/*.wav`: efeitos sonoros gerados para este projeto, sem dependências externas.
- `tests/integration.gd`: testes de fluxo no motor Godot.
- `tests/validate_math.py`: verificação independente do banco com conjuntos Python.
- `export_presets.cfg`: configurações de exportação Windows e Web.

A janela foi planejada para 1280 × 800 com escala automática. Conteúdos longos ficam em área rolável. O uso principal é em computador; não foi validado em smartphones.

## Exportar novamente

No Godot, instale os templates da versão 4.4.1 em Editor → Gerenciar modelos de exportação. Os presets distribuídos usam os templates padrão instalados, sem caminhos específicos deste ambiente. Em Projeto → Exportar, escolha Windows Desktop ou Web e selecione o destino. A versão Web não usa threads, dispensando os cabeçalhos especiais exigidos por builds com threads. Mantenha os arquivos exportados juntos.

## Disponibilização pública exigida pelo trabalho

Você pode distribuir o ZIP Windows por um link público de download ou hospedar os arquivos Web em um serviço de hospedagem estática com suporte a WebAssembly. O arquivo principal deve ser `index.html`; mantenha `.wasm`, `.pck`, `.js` e os demais recursos na mesma pasta. Abra o link final em outro computador antes de entregar no AVA. Nesta entrega existem os arquivos exportados; a publicação de um link público permanece a cargo da equipe.

## Verificações realizadas

- Importação e compilação pelo Godot 4.4.1.
- 142 verificações de integração: todas as 30 atividades, erro/acerto, novas tentativas, dicas, pontuação, proteção contra confirmação repetida, cinco missões, quiz balanceado, bloqueio de resposta em branco, encerramento e salvamento/carregamento.
- Gabaritos dos 30 desafios verificados por cálculo independente em Python e 15 respostas do quiz revisadas.
- Exportações Windows e Web concluídas pelo Godot.
- Revisão visual de cinco telas renderizadas no Godot com OpenGL: mapa, missão, feedback, subconjuntos e avaliação.

Executar os testes altera o progresso local de teste. Use um perfil separado ou apague o progresso pelo menu após rodar:

```sh
godot --headless --path . --script res://tests/integration.gd
python3 tests/validate_math.py
```

Nenhum teste automatizado garante ausência absoluta de erros. Faça um teste de uso na máquina da apresentação, inclusive áudio, leitura, resolução e acesso público.

## Relação com os critérios do PDF

| Critério | Entrega no jogo / ação da equipe |
|---|---|
| Pelo menos 5 interações | 15 desafios ao concluir os cinco setores |
| Banco de quiz com pelo menos 10 questões | Banco de 15, com sorteio de 10 |
| Instruções | Tutorial, introdução por setor, exemplos e dicas |
| Enredo | Lia, nave Atlas, recuperação dos setores e portal final |
| Conteúdo matemático | Cinco temas solicitados, explicações e gabaritos |
| Feedback visual e sonoro | Mensagem, símbolos, cores e efeitos de áudio |
| Acesso ao jogo | Pacotes Windows e Web; equipe deve disponibilizar o link |
| Apresentação em slides | Ainda deve ser preparada e entregue pela equipe |
| Testes de usabilidade AV3 | Ainda devem ser feitos com colegas/alunos reais |

## Roteiro sugerido da apresentação (5–10 minutos)

1. Público e problema: tornar operações com conjuntos concretas e interativas.
2. Objetivo e narrativa: recuperar a nave Atlas com cinco conceitos.
3. Desenvolvimento: Godot, GDScript, banco JSON e interface programática.
4. Demonstração: união/interseção e um desafio de subconjuntos; mostrar erro, dica e acerto.
5. Qualidade: revisão dos gabaritos, testes e acessibilidade das instruções.
6. Acesso: abrir o executável ou link público em outra máquina.
7. AV3: apresentar o plano de coleta de feedback.

## Ficha de teste de usabilidade

Peça a pelo menos três participantes para iniciar sem ajuda, concluir uma missão e fazer uma questão da avaliação. Registre, sem dados pessoais: tarefa concluída, dúvidas, erros de navegação e sugestões. Pergunte: as instruções ficaram claras? O feedback ajudou a entender o erro? Conseguiu explicar a operação depois? O texto e o som ficaram adequados? Não invente resultados; registre as observações reais e priorize as correções para AV3.

## Autoria dos recursos

Código, textos de jogo, formas vetoriais e sons produzidos para esta entrega. Fontes e componentes visuais padrão são fornecidos pelo Godot. A equipe deve identificar seus integrantes e descrever honestamente sua participação e o uso de assistência por IA conforme as regras da disciplina.
