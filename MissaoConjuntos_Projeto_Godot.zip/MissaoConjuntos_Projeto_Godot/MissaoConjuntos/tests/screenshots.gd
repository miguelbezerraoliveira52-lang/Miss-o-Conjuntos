extends SceneTree
func _initialize() -> void:
	call_deferred("run")
func snap(name: String) -> void:
	await process_frame
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("res://../output/"+name+".png")
func run() -> void:
	var game=load("res://main.tscn").instantiate()
	root.add_child(game)
	game.progress=[0,0,0,0,0]
	game.home()
	await snap("01_mapa")
	game.start_module(1)
	game.begin_module()
	await snap("02_missao")
	for i in game.session[0].answer: game.select_option(int(i))
	game.check_answer()
	await snap("03_feedback")
	game.start_module(4)
	game.begin_module()
	await snap("04_subconjuntos")
	game.start_quiz()
	await snap("05_avaliacao")
	quit()
