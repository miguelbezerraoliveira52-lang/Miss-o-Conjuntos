"""Validação independente do banco, usando conjuntos nativos do Python."""
import json
from pathlib import Path
D=json.loads((Path(__file__).parents[1]/'assets/data.json').read_text())
known_definition=[{2,4,6,8},{1,2,3},{2,3,5,7},set(),{1,2,3,4},set(range(1,9))]
for i,q in enumerate(D['levels']):
    m=q['module']; A=set(q['a']);B=set(q['b']);U=set(q['u'])
    assert A<=U and B<=U
    assert len(q['options'])==len(set(q['options']))
    if m==4:
        candidates=[set() if x=='∅' else set(map(int,x.strip('{}').split(','))) for x in q['options']]
        expected={i for i,x in enumerate(candidates) if x<=A}
    else:
        target=known_definition[i] if m==0 else (A|B if m==1 else A&B if m==2 else U-A)
        expected={i for i,x in enumerate(q['options']) if int(x) in target}
    assert set(q['answer'])==expected,(i,q)
key=[0,1,1,2,0,1,1,0,2,1,1,0,1,2,0]
assert [q['answer'][0] for q in D['quiz']]==key
assert len({q['prompt'] for q in D['quiz']})==15
print('PASS: 30 gabaritos de seleção e 15 gabaritos de quiz verificados.')
