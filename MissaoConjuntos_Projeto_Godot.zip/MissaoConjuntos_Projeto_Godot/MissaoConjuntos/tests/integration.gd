extends SceneTree
var game
var checks=0
func verify(condition: bool, message: String) -> void:
	checks+=1
	if not condition:
		push_error(message)
		quit(1)
func _initialize() -> void:
	call_deferred("run")
func run() -> void:
	game=load("res://main.tscn").instantiate()
	root.add_child(game)
	await process_frame
	game.muted=true
	game.progress=[0,0,0,0,0]
	game.best_quiz=0
	verify(game.data.levels.size()==30,"30 desafios")
	verify(game.data.quiz.size()==15,"15 questões")
	game.tutorial()
	await process_frame
	game.guide()
	await process_frame
	for m in range(5):
		game.start_module(m)
		game.begin_module()
		verify(game.session.size()==3,"3 por missão")
		for q in game.data.levels:
			if int(q.module)!=m: continue
			game.session=[q]
			game.current=0
			game.score=0
			game.show_question()
			await process_frame
			game.show_hint()
			verify(not game.hint.text.is_empty(),"Dica presente")
			game.selected=[99]
			game.check_answer()
			verify(not game.answered and game.mistakes==1,"Erro permite nova tentativa")
			game.selected=[]
			for i in q.answer: game.select_option(int(i))
			game.check_answer()
			if not (game.answered and game.score==75): print("FAIL QUESTION ",q," selected=",game.selected," score=",game.score," answered=",game.answered)
			verify(game.answered and game.score==75,"Resposta correta e pontuação")
			game.check_answer()
			verify(game.score==75,"Proteção contra pontuar duas vezes")
			game.advance()
			await process_frame
		game.begin_module()
		for j in range(3):
			game.selected=game.session[game.current].answer.duplicate()
			game.check_answer()
			game.advance()
			await process_frame
		verify(game.progress[m]==3,"Três estrelas")
	game.start_quiz()
	verify(game.session.size()==10,"Quiz tem 10 questões")
	for m in range(5):
		var count=0
		for q in game.session:
			if int(q.module)==m: count+=1
		verify(count==2,"Cobertura balanceada")
	game.check_answer()
	verify(not game.answered,"Quiz exige seleção")
	for j in range(10):
		game.select_option(int(game.session[game.current].answer[0]))
		game.check_answer()
		game.advance()
		await process_frame
	verify(game.score==10 and game.best_quiz==10,"Quiz completo")
	game.save_progress()
	game.progress=[0,0,0,0,0]
	game.best_quiz=0
	game.load_progress()
	verify(game.progress==[3,3,3,3,3] and game.best_quiz==10,"Persistência")
	game.start_quiz()
	game.select_option((int(game.session[0].answer[0])+1)%3)
	game.check_answer()
	verify(game.answered and game.score==0,"Erro no quiz é definitivo")
	game.home()
	print("PASS: ",checks," verificações de integração")
	quit(0)
