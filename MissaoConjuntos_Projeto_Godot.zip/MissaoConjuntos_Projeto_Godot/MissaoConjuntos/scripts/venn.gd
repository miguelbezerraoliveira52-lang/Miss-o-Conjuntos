extends Control
var a: Array = []
var b: Array = []
var u: Array = []
func _ready() -> void:
	custom_minimum_size = Vector2(0, 200)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
func _draw() -> void:
	var cx = size.x / 2.0
	var font = ThemeDB.fallback_font
	draw_style_box(box(), Rect2(Vector2.ZERO, size))
	draw_circle(Vector2(cx-65, 100), 85, Color(0.15,0.67,0.85,0.24))
	draw_circle(Vector2(cx+65, 100), 85, Color(0.70,0.42,0.96,0.24))
	draw_arc(Vector2(cx-65,100),85,0,TAU,64,Color("51d5ed"),2,true)
	draw_arc(Vector2(cx+65,100),85,0,TAU,64,Color("b49aff"),2,true)
	draw_string(font,Vector2(18,27),"U • universo",HORIZONTAL_ALIGNMENT_LEFT,-1,18,Color("a8b9d3"))
	draw_string(font,Vector2(cx-115,36),"A",0,-1,22,Color("51d5ed"))
	draw_string(font,Vector2(cx+99,36),"B",0,-1,22,Color("b49aff"))
	var left: Array=[]
	var common: Array=[]
	var right: Array=[]
	var outside: Array=[]
	for x in u:
		if x in a and x in b: common.append(x)
		elif x in a: left.append(x)
		elif x in b: right.append(x)
		else: outside.append(x)
	region(left,Vector2(cx-113,80),font)
	region(common,Vector2(cx-13,80),font)
	region(right,Vector2(cx+85,80),font)
	draw_string(font,Vector2(18,184),"Fora de A e B: " + values(outside),0,-1,17,Color("c4d1e5"))
func region(items: Array, pos: Vector2, font: Font) -> void:
	for i in range(items.size()):
		draw_string(font,pos+Vector2((i%2)*24,(i/2)*26),str(int(items[i])),0,-1,20,Color.WHITE)
func values(items: Array) -> String:
	var s: PackedStringArray=[]
	for x in items: s.append(str(int(x)))
	return ", ".join(s) if not s.is_empty() else "nenhum"
func box() -> StyleBoxFlat:
	var s=StyleBoxFlat.new()
	s.bg_color=Color("101c32")
	s.set_corner_radius_all(14)
	return s
