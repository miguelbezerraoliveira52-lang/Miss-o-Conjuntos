extends Control
const Venn = preload("res://scripts/venn.gd")
const SAVE = "user://progress.cfg"
var data: Dictionary
var progress: Array = [0,0,0,0,0]
var best_quiz: int = 0
var muted: bool = false
var root: VBoxContainer
var scroll: ScrollContainer
var content: VBoxContainer
var audio: AudioStreamPlayer
var session: Array = []
var selected: Array = []
var option_buttons: Array = []
var current: int = 0
var module_id: int = 0
var quiz_mode: bool = false
var score: int = 0
var mistakes: int = 0
var answered: bool = false
var feedback: Label
var confirm: Button
var next_button: Button
var status: Label
var hint: Label
var sound_button: Button
var save_warning: String = ""

func _ready() -> void:
	data = JSON.parse_string(FileAccess.get_file_as_string("res://assets/data.json"))
	load_progress()
	make_theme()
	audio=AudioStreamPlayer.new()
	add_child(audio)
	var margin=MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left","right","top","bottom"]: margin.add_theme_constant_override("margin_"+side,28)
	add_child(margin)
	root=VBoxContainer.new()
	root.add_theme_constant_override("separation",16)
	margin.add_child(root)
	var top=HBoxContainer.new()
	root.add_child(top)
	var brand=label("◈  MISSÃO CONJUNTOS",24,Color("64e3dc"))
	brand.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	top.add_child(brand)
	top.add_child(button("Início",home))
	top.add_child(button("Como jogar",tutorial))
	sound_button=button("",toggle_sound)
	top.add_child(sound_button)
	update_sound_label()
	scroll=ScrollContainer.new()
	scroll.size_flags_vertical=Control.SIZE_EXPAND_FILL
	root.add_child(scroll)
	content=VBoxContainer.new()
	content.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation",14)
	scroll.add_child(content)
	home()

func make_theme() -> void:
	var t=Theme.new()
	t.default_font_size=19
	for state in ["normal","hover","pressed","focus","disabled"]:
		var s=StyleBoxFlat.new()
		s.bg_color=Color("203653") if state=="normal" else Color("2f5875")
		if state=="pressed": s.bg_color=Color("176d79")
		if state=="disabled": s.bg_color=Color("182338")
		s.set_corner_radius_all(10)
		s.content_margin_left=18
		s.content_margin_right=18
		s.content_margin_top=12
		s.content_margin_bottom=12
		if state=="focus":
			s.bg_color=Color.TRANSPARENT
			s.set_border_width_all(2)
			s.border_color=Color("ffe29a")
		t.set_stylebox(state,"Button",s)
	t.set_color("font_color","Label",Color("e4edf9"))
	t.set_color("font_disabled_color","Button",Color("9badc8"))
	theme=t

func label(text: String, font_size: int=19, color: Color=Color("e4edf9")) -> Label:
	var l=Label.new()
	l.text=text
	l.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	l.add_theme_font_size_override("font_size",font_size)
	l.add_theme_color_override("font_color",color)
	return l

func button(text: String, action: Callable) -> Button:
	var b=Button.new()
	b.text=text
	b.mouse_default_cursor_shape=Control.CURSOR_POINTING_HAND
	b.pressed.connect(action)
	return b

func clear() -> void:
	scroll.scroll_vertical=0
	for node in content.get_children():
		content.remove_child(node)
		node.queue_free()
	option_buttons.clear()

func heading(kicker: String, title: String, description: String) -> void:
	content.add_child(label(kicker,16,Color("64e3dc")))
	content.add_child(label(title,36))
	content.add_child(label(description,20,Color("b8c9e1")))

func panel() -> VBoxContainer:
	var p=PanelContainer.new()
	var s=StyleBoxFlat.new()
	s.bg_color=Color("132139")
	s.set_corner_radius_all(16)
	for side in ["left","right","top","bottom"]: s.set("content_margin_"+side,20)
	p.add_theme_stylebox_override("panel",s)
	content.add_child(p)
	var v=VBoxContainer.new()
	v.add_theme_constant_override("separation",12)
	p.add_child(v)
	return v

func home() -> void:
	clear()
	heading("UMA EXPEDIÇÃO MATEMÁTICA • ENSINO MÉDIO","Reconstrua o mapa da Atlas.","Uma tempestade embaralhou os arquivos da nave. Ajude Lia a recuperar cinco setores usando conjuntos e reativar o portal de volta para casa.")
	var v=panel()
	v.add_child(label("Escolha um setor",25))
	v.add_child(label("Cada missão sorteia 3 desafios. Aprenda, selecione e confirme. Erros permitem novas tentativas, sem limite de tempo.",18))
	for i in range(5):
		var m: Dictionary=data.modules[i]
		var stars="★".repeat(int(progress[i]))+"☆".repeat(3-int(progress[i]))
		var b=button("%02d   %s  •  %s       %s" % [i+1,m.topic,m.title,stars],start_module.bind(i))
		b.alignment=HORIZONTAL_ALIGNMENT_LEFT
		v.add_child(b)
	var row=HBoxContainer.new()
	content.add_child(row)
	row.add_child(button("Avaliação final • 10 questões",start_quiz))
	row.add_child(button("Guia de conjuntos",guide))
	row.add_child(button("Apagar progresso",reset_dialog))
	content.add_child(label("Recorde da avaliação: %d/10  •  Progresso salvo neste dispositivo  •  Som opcional" % best_quiz,16,Color("9eb1cc")))
	if not save_warning.is_empty(): content.add_child(label(save_warning,16,Color("ffe29a")))

func tutorial() -> void:
	clear()
	heading("MANUAL DE BORDO","Como jogar","Sua missão é restaurar os cinco setores da Atlas. Você pode visitar os setores em qualquer ordem.")
	var v=panel()
	for s in ["1. Escolha um setor e leia a explicação e o exemplo antes de começar.","2. Nos desafios, clique nos elementos que fazem parte da resposta. Clique novamente para desmarcar.","3. Em Subconjuntos, cada botão é um conjunto inteiro. Selecione todos os subconjuntos válidos.","4. Para responder conjunto vazio, deixe todos os botões desmarcados e clique em Confirmar.","5. Se errar, leia a explicação, ajuste a seleção e tente novamente. A dica não retira pontos.","6. Cada desafio vale 100 pontos na primeira tentativa, 75 na segunda e 50 nas seguintes. Concluir dá 1 estrela; 225 pontos dão 2; 300 dão 3.","7. A avaliação sorteia 2 questões de cada tema. Nela, cada resposta é definitiva e o feedback mostra o gabarito.","8. Use mouse ou Tab / Shift+Tab para navegar e Espaço / Enter para acionar botões. Não há cronômetro.","9. Voltar ao início encerra a missão em andamento. Estrelas de missões concluídas e o recorde ficam salvos."]:
		v.add_child(label(s))
	content.add_child(button("Entendi • escolher missão",home))

func guide() -> void:
	clear()
	heading("BIBLIOTECA DA ATLAS","Guia de conjuntos","Consulte os conceitos e volte às missões quando quiser.")
	for m in data.modules:
		var v=panel()
		v.add_child(label(m.topic,25,Color("64e3dc")))
		v.add_child(label(m.theory))
	content.add_child(button("Voltar",home))

func start_module(id: int) -> void:
	module_id=id
	quiz_mode=false
	clear()
	var m: Dictionary=data.modules[id]
	heading("SETOR %02d • %s" % [id+1,m.topic],m.title,m.story)
	var v=panel()
	v.add_child(label("Antes da missão",25,Color("64e3dc")))
	v.add_child(label(m.theory,23))
	var examples=["{1, 2, 2, 3} = {3, 2, 1}. Ambos têm os mesmos três elementos.","Se A = {1, 2} e B = {2, 3}, então A ∪ B = {1, 2, 3}.","Se A = {1, 2} e B = {2, 3}, então A ∩ B = {2}.","Se U = {1, 2, 3, 4} e A = {2, 4}, então Aᶜ = {1, 3}.","Se A = {1, 2}, então ∅, {1}, {2} e {1, 2} são subconjuntos de A."]
	v.add_child(label("Exemplo: "+examples[id],22,Color("ffe29a")))
	content.add_child(button("Iniciar os 3 desafios",begin_module))

func begin_module() -> void:
	session=[]
	for q in data.levels:
		if int(q.module)==module_id: session.append(q)
	session.shuffle()
	session=session.slice(0,3)
	current=0
	score=0
	show_question()

func start_quiz() -> void:
	quiz_mode=true
	session=[]
	for m in range(5):
		var pool: Array=[]
		for q in data.quiz:
			if int(q.module)==m: pool.append(q)
		pool.shuffle()
		session.append_array(pool.slice(0,2))
	session.shuffle()
	current=0
	score=0
	show_question()

func format_set(xs: Array) -> String:
	if xs.is_empty(): return "∅"
	var result: PackedStringArray=[]
	for x in xs: result.append(str(int(x)))
	return "{"+", ".join(result)+"}"

func show_question() -> void:
	clear()
	selected=[]
	answered=false
	mistakes=0
	var q: Dictionary=session[current]
	var topic: String=data.modules[int(q.module)].topic
	heading("%s • %d / %d • %s" % ["AVALIAÇÃO" if quiz_mode else "MISSÃO",current+1,session.size(),topic],q.prompt,"Selecione uma alternativa." if quiz_mode else "Selecione todos os itens corretos. Para uma resposta vazia, não selecione nenhum.")
	var bar=ProgressBar.new()
	bar.max_value=session.size()
	bar.value=current
	bar.show_percentage=false
	bar.custom_minimum_size.y=8
	content.add_child(bar)
	if not quiz_mode:
		content.add_child(label("U = %s     A = %s     B = %s" % [format_set(q.u),format_set(q.a),format_set(q.b)] if int(q.module) in [1,2] else ("U = %s     A = %s" % [format_set(q.u),format_set(q.a)] if int(q.module)>=3 else "U = "+format_set(q.u)),22,Color("ffe29a")))
		if int(q.module) in [1,2]:
			var diagram=Venn.new()
			diagram.a=q.a
			diagram.b=q.b
			diagram.u=q.u
			content.add_child(diagram)
	var grid=GridContainer.new()
	grid.columns=1 if quiz_mode else (3 if int(q.module)==4 else 8)
	grid.add_theme_constant_override("h_separation",10)
	grid.add_theme_constant_override("v_separation",10)
	content.add_child(grid)
	for i in range(q.options.size()):
		var b=button(str(q.options[i]),select_option.bind(i))
		b.toggle_mode=true
		b.size_flags_horizontal=Control.SIZE_EXPAND_FILL
		b.custom_minimum_size.y=56
		grid.add_child(b)
		option_buttons.append(b)
	status=label("Nenhuma seleção",17,Color("a8b9d3"))
	content.add_child(status)
	var row=HBoxContainer.new()
	content.add_child(row)
	confirm=button("Confirmar resposta",check_answer)
	row.add_child(confirm)
	row.add_child(button("Consultar dica",show_hint))
	next_button=button("Próximo",advance)
	next_button.visible=false
	row.add_child(next_button)
	hint=label("",18,Color("ffe29a"))
	content.add_child(hint)
	feedback=label("",21)
	content.add_child(feedback)
	confirm.grab_focus()

func select_option(i: int) -> void:
	if answered: return
	if quiz_mode:
		selected=[i]
		for j in range(option_buttons.size()): option_buttons[j].set_pressed_no_signal(j==i)
	else:
		if i in selected: selected.erase(i)
		else: selected.append(i)
	for j in range(option_buttons.size()):
		option_buttons[j].text=("✓ " if j in selected else "")+str(session[current].options[j])
	status.text="%d item(ns) selecionado(s)" % selected.size() if not selected.is_empty() else "Nenhuma seleção • resposta vazia"
	play_sound("click")

func show_hint() -> void:
	hint.text=data.modules[int(session[current].module)].theory

func is_correct(choice: Array, expected: Array) -> bool:
	if choice.size()!=expected.size(): return false
	var normalized: Array=[]
	for x in expected: normalized.append(int(x))
	for x in choice:
		if not int(x) in normalized: return false
	return true

func check_answer() -> void:
	if answered: return
	var q: Dictionary=session[current]
	if quiz_mode and selected.is_empty():
		feedback.text="Selecione uma alternativa antes de confirmar."
		return
	var correct=is_correct(selected,q.answer)
	play_sound("correct" if correct else "wrong")
	feedback.add_theme_color_override("font_color",Color("72edbf") if correct else Color("ffb4aa"))
	if correct or quiz_mode:
		answered=true
		if correct: score+=1 if quiz_mode else maxi(50,100-25*mistakes)
		var solutions: PackedStringArray=[]
		for i in q.answer: solutions.append(str(q.options[int(i)]))
		feedback.text=("✓ Correto! " if correct else "✕ Resposta incorreta. ")+q.explanation+"\nGabarito: "+(", ".join(solutions) if not solutions.is_empty() else "∅ (nenhum elemento)")
		confirm.disabled=true
		for b in option_buttons: b.disabled=true
		next_button.visible=true
		next_button.text="Ver resultado" if current==session.size()-1 else "Próximo desafio"
		next_button.grab_focus()
	else:
		mistakes+=1
		feedback.text="✕ Ainda não. "+q.explanation+"\nAjuste sua seleção e confirme novamente."
	reveal_feedback.call_deferred(feedback)

func reveal_feedback(target: Control) -> void:
	await get_tree().process_frame
	if is_instance_valid(target) and scroll.is_ancestor_of(target):
		scroll.ensure_control_visible(target)

func advance() -> void:
	if not answered: return
	current+=1
	if current<session.size(): show_question()
	else: results()

func results() -> void:
	clear()
	if quiz_mode:
		best_quiz=maxi(best_quiz,score)
		heading("AVALIAÇÃO CONCLUÍDA","%d de 10 respostas corretas" % score,"A Atlas registrou sua avaliação. Revise os setores em que teve dificuldade e faça uma nova expedição.")
	else:
		var stars=3 if score==300 else (2 if score>=225 else 1)
		progress[module_id]=maxi(int(progress[module_id]),stars)
		heading("SETOR RESTAURADO", "★".repeat(stars)+"☆".repeat(3-stars),"Você recuperou o setor %s e conquistou %d pontos de 300." % [data.modules[module_id].topic,score])
	var all_done=true
	for x in progress:
		if int(x)==0: all_done=false
	var v=panel()
	v.add_child(label("Portal reativado!" if all_done else "A expedição continua",28,Color("64e3dc")))
	v.add_child(label("Lia restaurou os cinco setores e a nave Atlas pode voltar para casa. Continue praticando para conquistar todas as estrelas!" if all_done else "Complete os cinco setores para restaurar o portal. Suas melhores estrelas ficam guardadas."))
	save_progress()
	content.add_child(button("Voltar ao mapa",home))
	content.add_child(button("Jogar novamente",start_quiz if quiz_mode else begin_module))

func play_sound(kind: String) -> void:
	if muted: return
	audio.stream=load("res://assets/"+kind+".wav")
	audio.play()
func toggle_sound() -> void:
	muted=not muted
	if muted: audio.stop()
	update_sound_label()
	save_progress()
func update_sound_label() -> void:
	sound_button.text="Som: desligado" if muted else "Som: ligado"
func save_progress() -> void:
	var cfg=ConfigFile.new()
	cfg.set_value("game","stars",progress)
	cfg.set_value("game","best",best_quiz)
	cfg.set_value("game","muted",muted)
	var err=cfg.save(SAVE)
	save_warning="Não foi possível salvar o progresso neste dispositivo." if err!=OK else ""
func load_progress() -> void:
	var cfg=ConfigFile.new()
	if cfg.load(SAVE)!=OK: return
	var stars=cfg.get_value("game","stars",[0,0,0,0,0])
	if stars is Array and stars.size()==5:
		for i in range(5):
			if stars[i] is int or stars[i] is float: progress[i]=clampi(int(stars[i]),0,3)
	best_quiz=clampi(int(cfg.get_value("game","best",0)),0,10)
	muted=bool(cfg.get_value("game","muted",false))
func reset_dialog() -> void:
	var dialog=ConfirmationDialog.new()
	dialog.title="Apagar progresso?"
	dialog.dialog_text="As estrelas e o recorde serão apagados deste dispositivo."
	dialog.confirmed.connect(func():
		progress=[0,0,0,0,0]
		best_quiz=0
		save_progress()
		home()
		dialog.queue_free())
	dialog.canceled.connect(dialog.queue_free)
	add_child(dialog)
	dialog.popup_centered()
